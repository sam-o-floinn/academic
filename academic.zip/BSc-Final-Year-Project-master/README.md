# BSc-Final-Year-Project
Final Year Project.

Video game made in UnrealScript to simulate flight.

File contains numerous different actor and controller scripts, for elements such as the camera, the pawn (player character),
the enemy AI and the game's win conditions.

Files attached do NOT include the UDK engine that is required to run it. To run it would require installing Unreal Engine 3
and configuring it to these files.
