# BSc-Assignments
Assignments and smaller projects throughout UCC's BSc 2009-2013 course
